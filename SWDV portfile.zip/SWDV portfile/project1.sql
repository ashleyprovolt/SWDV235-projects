--drop database ashleyBD;
--go
create database ashleyBD;
go

use ashleyBD;
go 

CREATE TABLE Contact (
 ContactID int IDENTITY(1,1)  not null primary key,
 ContactFName nchar(25) not null,
 ContactLName nchar(25) not null,
 ContactEmail nchar(40) not null,
 ContactComments nchar(500) not null) 

go

create procedure InsertContact
@ContactFName nchar(25),
@ContactLName nchar(25),
@ContactEmail nchar(40),
@ContactComments nchar(500)
as
INSERT INTO [ashleyBD].[dbo].[Contact]
           ([ContactFName]
           ,[ContactLName]
           ,[ContactEmail]
		   ,[ContactComments])
     VALUES
           (@ContactFName
           ,@ContactLName
           ,@ContactEmail
		   ,@ContactComments)
GO

execute InsertContact "Mickey", "Mouse", "mickey@mouse.com", "Insert using SP from SSMS";

select * from Contact;

/*Creating a long in and user */
 CREATE LOGIN [ashleyBDcontact] WITH PASSWORD='Pa$$w0rd', DEFAULT_DATABASE=[ashleyBD]
go
use ashleyBD
go

CREATE USER [ashleyBDcontact] FOR LOGIN [ashleyBDcontact] WITH DEFAULT_SCHEMA=[dbo]
GO
grant execute on InsertContact to  ashleyBDcontact
go

/*CREATE USER [jimmy] FOR LOGIN [ashleyBDcontact] WITH DEFAULT_SCHEMA=[dbo]
GO
grant execute on InsertContact to jimmy
go	  */

